import cv2


def zoom_image(input_image_path, zoom_factor):
   
    img = cv2.imread(input_image_path)
    
  
    if img is None:
        print("Image not found. Please enter a valid path.")
        return

   
    height, width = img.shape[:2]
    new_width = int(width * zoom_factor)
    new_height = int(height * zoom_factor)

  
    zoomed_img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_LINEAR)

    
    cv2.imshow("Zoomed Image", zoomed_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


input_image_path = input("Please enter the image path: ")
zoom_factor = float(input("Please enter the zoom factor : "))


zoom_image(input_image_path, zoom_factor)