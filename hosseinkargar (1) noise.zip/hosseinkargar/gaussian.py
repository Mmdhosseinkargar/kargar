import cv2
import numpy as np


image = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)

if image is None:
    print("Error: تصویر بارگذاری نشد.")
else:
  
    mean = 0
    sigma = 25 
    gaussian_noise = np.random.normal(mean, sigma, image.shape).astype(np.int16)
    noisy_image = cv2.add(image.astype(np.int16), gaussian_noise)
    noisy_image = np.clip(noisy_image, 0, 255).astype(np.uint8) 


    denoised_image = cv2.GaussianBlur(noisy_image, (5, 5), 0)

 
    cv2.imshow("Original Image", image)
    cv2.imshow("Noisy Image", noisy_image)
    cv2.imshow("Denoised Image", denoised_image)

 
    cv2.waitKey(0)
    cv2.destroyAllWindows()
