import cv2
import numpy as np


img = np.zeros((400, 400, 3), dtype=np.uint8)


color1 = (255, 0, 0)
color2 = (0, 255, 0)  


for y in range(img.shape[0]):
    for x in range(img.shape[1]):
       
        alpha = (x + y) / (img.shape[0] + img.shape[1])
        
        
        b = int(color1[0] * (1 - alpha) + color2[0] * alpha)
        g = int(color1[1] * (1 - alpha) + color2[1] * alpha)
        r = int(color1[2] * (1 - alpha) + color2[2] * alpha)

        color = (b, g, r) 
        
        
        img[y, x] = color


cv2.imshow(" Blue to Green", img)
cv2.waitKey(0)  
cv2.destroyAllWindows()  